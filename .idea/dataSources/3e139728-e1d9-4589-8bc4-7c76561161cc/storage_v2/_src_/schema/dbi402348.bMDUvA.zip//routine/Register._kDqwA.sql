create
  definer = dbi402348@`%` procedure Register(IN name varchar(255), IN pass varchar(255))
BEGIN
  INSERT INTO Users (Username, Password) VALUES(name, pass);
END;

