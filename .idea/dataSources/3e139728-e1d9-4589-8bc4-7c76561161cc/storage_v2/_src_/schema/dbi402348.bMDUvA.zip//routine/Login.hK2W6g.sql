create
  definer = dbi402348@`%` procedure Login(IN usernameIn varchar(255), IN passwordIn varchar(255))
BEGIN
  SELECT Id, Username
  FROM users
  WHERE Username = usernameIn AND Password = passwordIn
  LIMIT 1;
END;

