create
  definer = dbi402348@`%` procedure Login(IN usernameIn varchar(255), IN passwordIn varchar(255), OUT idOut int,
                                          OUT usernameOut varchar(255))
BEGIN
  SELECT Id INTO idOut
  FROM users
  WHERE Username = usernameIn AND Password = passwordIn
  LIMIT 1;

  SELECT Username INTO usernameOut
  FROM users
  WHERE Username = usernameIn AND Password = passwordIn
  LIMIT 1;
END;

