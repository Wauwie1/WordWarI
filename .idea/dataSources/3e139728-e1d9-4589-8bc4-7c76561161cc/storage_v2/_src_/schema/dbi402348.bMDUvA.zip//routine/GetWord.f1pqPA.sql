create
  definer = dbi402348@`%` procedure GetWord(IN idIn int, OUT wordOut varchar(255))
BEGIN
  SELECT Word INTO wordOut
  FROM words
  WHERE id = idIn
  LIMIT 1;
END;

